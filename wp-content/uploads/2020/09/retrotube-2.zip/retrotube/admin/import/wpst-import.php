<?php 

class wpst_import extends WP_Import {
    function check(){
    //you can add any extra custom functions after the importing of demo coment is done
    }
}